/*write a program for bubble sorting*/

#include <stdio.h>
int main()
{
    int number[170], count, i,j,temp;
    printf("HOW MANY NO. DO YOU WANT TO ENTER : ");
    scanf("%d",&count);
    printf("ENTER %d NO. ONE BY ONE : ",count);
    
    for(i=0; i<count; i++)
    {
        scanf("%d",&number[i]);
    }
    for(i=0; i<count; i++)
    {
        for(j=0; j<(count-i-1); j++)
        {
            if(number[j]>number[j+1])
            {
                temp = number[j];
                number[j] = number[j+1];
                number[j+1] = temp;
            }
        }
    }
    printf("THE SORTED NP'S IS : \n");
    for(i=0; i<count; i++)
    {
        printf("%d ",number[i]);
    }
    return 0;
}