/* 2. Design an algortihm and write a program for selection sort */

#include<stdio.h>
int main()
{
    int i,j,n,loc,temp,min,num[50];
    printf("Enter the number of elements:");
    scanf("%d",&n);
    printf("\nEnter the elements\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&num[i]);
    }
    for(i=0;i<n-1;i++)    
    {
        min=num[i];
        loc=i;
        for(j=i+1;j<n;j++)
        {
            if(min>num[j])
            {
                min=num[j];
                loc=j;
            }
        }
    temp=num[i];
    num[i]=num[loc];
    num[loc]=temp;
    }
    printf("\nSorted list is as follows\n");
    for(i=0;i<n;i++)
    {
        printf("%d",num[i]);
    }
    return 0;
}